#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
The key idea of this program is to equate the strings
"rock", "paper", "scissors", "lizard", "Spock" to numbers
as follows:

 0 - rock
 1 - Spock
 2 - paper
 3 - lizard
 4 - scissors
"""


