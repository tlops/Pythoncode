#!/usr/bin/env python

def addtwo ():
    try:
        a=input("first No: ")
        b=input("second no: ")

        return a +b
    except :
        print ("Enter integer value! ")

print addtwo ()
