#!/usr/bin/env python
# -*- coding: utf-8 -*-

import fibonacci

a = fibonacci.fib(10)

print ""
print (fibonacci.fibonan(10))

